import sqlite3
from datetime import datetime
from fpdf import FPDF

def inicializar_banco():
    conexao = sqlite3.connect('usuarios.db')
    cursor = conexao.cursor()
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS usuarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT NOT NULL UNIQUE,
        senha TEXT NOT NULL
    )
    ''')
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS testes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario_id INTEGER,
        descricao TEXT,
        resultado TEXT,
        equipamentos TEXT,
        om_responsavel TEXT,
        data_inicio TEXT,
        data_fim TEXT,
        autor TEXT,
        titulo TEXT,
        FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
    )
    ''')
    try:
        cursor.execute("ALTER TABLE testes ADD COLUMN autor TEXT")
    except sqlite3.OperationalError:
        pass

    try:
        cursor.execute("ALTER TABLE testes ADD COLUMN titulo TEXT")
    except sqlite3.OperationalError:
        pass
    conexao.commit()
    conexao.close()

def salvar_teste(usuario_id, descricao, resultado, equipamentos, om_responsavel, autor, titulo, data_inicio, data_fim):
    conexao = sqlite3.connect('usuarios.db')
    cursor = conexao.cursor()
    try:
        data_inicio_dt = datetime.strptime(data_inicio, '%d/%m/%y').strftime('%y-%m-%d')
        data_fim_dt = datetime.strptime(data_fim, '%d/%m/%y').strftime('%y-%m-%d')
        cursor.execute(''' 
        INSERT INTO testes (usuario_id, descricao, resultado, equipamentos, om_responsavel, autor, titulo, data_inicio, data_fim)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (usuario_id, descricao, resultado, equipamentos, om_responsavel, autor, titulo, data_inicio_dt, data_fim_dt))
        conexao.commit()
        gerar_pdf(usuario_id, descricao, resultado, equipamentos, om_responsavel, autor, titulo, data_inicio_dt, data_fim_dt)
    except sqlite3.Error as e:
        print(f"Erro ao salvar teste: {e}")
    finally:
        conexao.close()

def pesquisar_testes(material):
    conn = sqlite3.connect('usuarios.db')
    cursor = conn.cursor()
    query = "SELECT * FROM testes WHERE descricao LIKE ?"
    cursor.execute(query, ('%' + material + '%',))
    resultados = cursor.fetchall()
    conn.close()
    return resultados

def gerar_pdf(usuario_id, descricao, resultado, equipamentos, om_responsavel, autor, titulo, data_inicio, data_fim):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, txt=f"Descrição: {descricao}", ln=True)
    pdf.cell(200, 10, txt=f"Resultado: {resultado}", ln=True)
    pdf.cell(200, 10, txt=f"Equipamentos: {equipamentos}", ln=True)
    pdf.cell(200, 10, txt=f"OM Responsável: {om_responsavel}", ln=True)
    pdf.cell(200, 10, txt=f"Autor: {autor}", ln=True)
    pdf.cell(200, 10, txt=f"Título: {titulo}", ln=True)
    pdf.cell(200, 10, txt=f"Data Início: {data_inicio}", ln=True)
    pdf.cell(200, 10, txt=f"Data Fim: {data_fim}", ln=True)
    nome_arquivo = f"{autor}_{titulo}.pdf".replace(" ", "_")
    pdf.output(nome_arquivo)
    print(f"PDF gerado: {nome_arquivo}")
