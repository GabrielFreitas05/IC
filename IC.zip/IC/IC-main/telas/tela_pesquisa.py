import tkinter as tk
from tkinter import messagebox
from db.db import pesquisar_testes, gerar_pdf
from datetime import datetime

def voltar_tela_inicial(usuario_id):
    testes_window.destroy()
    from telas.tela_usuario import tela_usuario
    tela_usuario(usuario_id)


def tela_pesquisa(usuario_id):
    def realizar_pesquisa():
        material = entry_material.get().strip()

        if not material:
            messagebox.showerror("Erro", "Por favor, insira um material.")
            return

        resultados = pesquisar_testes(material)

        if resultados:
            exibir_resultados(resultados)
        else:
            messagebox.showinfo("Nenhum Resultado", "Nenhum teste encontrado para o material informado.")

    def exibir_resultados(resultados):
        for widget in frame_resultados.winfo_children():
            widget.destroy()

        for idx, resultado in enumerate(resultados):
            titulo= resultado[3]
            data_inicio = resultado[6]
            data_fim = resultado[7]
            autor = resultado[8]

            try:
                data_inicio_formatada = datetime.strptime(data_inicio, "%d-%m-%y").strftime("%d/%m/%y")
                data_fim_formatada = datetime.strptime(data_fim, "%d-%m-%y").strftime("%d/%m/%y")
            except ValueError:
                data_inicio_formatada = data_inicio
                data_fim_formatada = data_fim
                autor = autor

            tk.Label(frame_resultados, text=f"Título: {titulo}").grid(row=idx, column=0, sticky="w")
            tk.Label(frame_resultados, text=f"Data Início: {data_inicio_formatada}").grid(row=idx, column=1, sticky="w")
            tk.Label(frame_resultados, text=f"Data Fim: {data_fim_formatada}").grid(row=idx, column=2, sticky="w")
            tk.Label(frame_resultados, text=f"Autor: {autor}").grid(row=idx, column=3, sticky="w")
            
            button_gerar_pdf = tk.Button(frame_resultados, text="Gerar Relatório", command=lambda r=resultado: gerar_relatorio_pdf(r))
            button_gerar_pdf.grid(row=idx, column=7, padx=10, pady=5)

    def gerar_relatorio_pdf(resultado):
        descricao = resultado[2]
        data_inicio = resultado[7]
        data_fim = resultado[8]
        gerar_pdf(usuario_id, descricao, "", "", "", "", "", data_inicio, data_fim)
        messagebox.showinfo("Sucesso", f"Relatório para {descricao} gerado com sucesso!")

    pesquisa_window = tk.Tk()
    pesquisa_window.title("Pesquisa de Testes")
    pesquisa_window.geometry("800x600")

    tk.Label(pesquisa_window, text="Pesquisar por Material:").pack(pady=5)
    entry_material = tk.Entry(pesquisa_window)
    entry_material.pack(pady=5)

    button_pesquisar = tk.Button(pesquisa_window, text="Pesquisar", command=realizar_pesquisa)
    button_pesquisar.pack(pady=10)

    tk.Button(pesquisa_window, text="Voltar à Tela Inicial", command=lambda: pesquisa_window.destroy()).pack(pady=10)
    
    frame_resultados = tk.Frame(pesquisa_window)
    frame_resultados.pack(pady=10)

    pesquisa_window.mainloop()
