import tkinter as tk
from tkinter import messagebox
from tkcalendar import DateEntry
from db.db import inicializar_banco, salvar_teste
from datetime import datetime


def limpar_campos():
    descricao_entry.delete("1.0", tk.END)
    resultado_entry.delete(0, tk.END)
    equipamentos_entry.delete(0, tk.END)
    om_responsavel_entry.delete(0, tk.END)
    autor_entry.delete(0, tk.END)
    titulo_entry.delete(0, tk.END)
    data_inicio_entry.set_date(datetime.today())
    data_fim_entry.set_date(datetime.today())


def tela_testes(usuario_id):
    global descricao_entry, resultado_entry, equipamentos_entry, om_responsavel_entry, autor_entry, titulo_entry, data_inicio_entry, data_fim_entry

    janela = tk.Tk()
    janela.title("Cadastro de Testes")
    janela.geometry("800x600")

    tk.Label(janela, text="Autor:").pack()
    autor_entry = tk.Entry(janela)
    autor_entry.pack()

    tk.Label(janela, text="Título:").pack()
    titulo_entry = tk.Entry(janela)
    titulo_entry.pack()

    tk.Label(janela, text="Descrição:").pack()
    descricao_entry = tk.Text(janela, height=5, width=50)
    descricao_entry.pack()

    tk.Label(janela, text="Resultado:").pack()
    resultado_entry = tk.Entry(janela)
    resultado_entry.pack()

    tk.Label(janela, text="Equipamentos:").pack()
    equipamentos_entry = tk.Entry(janela)
    equipamentos_entry.pack()

    tk.Label(janela, text="OM Responsável:").pack()
    om_responsavel_entry = tk.Entry(janela)
    om_responsavel_entry.pack()

    tk.Label(janela, text="Data Início:").pack()
    data_inicio_entry = DateEntry(janela)
    data_inicio_entry.pack()

    tk.Label(janela, text="Data Fim:").pack()
    data_fim_entry = DateEntry(janela)
    data_fim_entry.pack()

    tk.Button(janela, text="Salvar Teste", command=lambda: salvar_teste(
        usuario_id,
        descricao_entry.get("1.0", tk.END).strip(),
        resultado_entry.get(),
        equipamentos_entry.get(),
        om_responsavel_entry.get(),
        autor_entry.get(),
        titulo_entry.get(),
        data_inicio_entry.get(),
        data_fim_entry.get()
    )).pack(pady=10)

    tk.Button(janela, text="Limpar Campos", command=limpar_campos).pack(pady=10)

    janela.mainloop()


if __name__ == "__main__":
    inicializar_banco()
    tela_testes(usuario_id=1)
