import tkinter as tk
from tkinter import messagebox
from tkcalendar import DateEntry
from datetime import datetime
from db.db import salvar_teste

def verificar_datas(data_inicio, data_fim):
    try:
        data_inicio_obj = datetime.strptime(data_inicio, "%d/%m/%y")
        data_fim_obj = datetime.strptime(data_fim, "%d/%m/%y")
        if data_fim_obj < data_inicio_obj:
            return False
        return True
    except ValueError:
        return False

def limpar_campos():
    descricao_entry.delete("1.0", tk.END)
    resultado_entry.delete(0, tk.END)
    equipamentos_entry.delete(0, tk.END)
    om_responsavel_entry.delete(0, tk.END)
    autor_entry.delete(0, tk.END)
    titulo_entry.delete(0, tk.END)
    data_inicio_entry.set_date(datetime.today())
    data_fim_entry.set_date(datetime.today())

def voltar_tela_inicial(usuario_id):
    testes_window.destroy()
    from telas.tela_usuario import tela_usuario
    tela_usuario(usuario_id)

def tela_testes(usuario_id):
    global testes_window
    global descricao_entry, resultado_entry, equipamentos_entry, om_responsavel_entry, autor_entry, titulo_entry, data_inicio_entry, data_fim_entry

    testes_window = tk.Tk()
    testes_window.title("Tela de Testes")
    testes_window.geometry("1920x1080")

    tk.Label(testes_window, text="Autor:").pack()
    autor_entry = tk.Entry(testes_window)
    autor_entry.pack()

    tk.Label(testes_window, text="Título:").pack()
    titulo_entry = tk.Entry(testes_window)
    titulo_entry.pack()

    tk.Label(testes_window, text="Descrição do Teste:").pack()
    descricao_entry = tk.Text(testes_window, height=5, width=20)
    descricao_entry.pack()

    tk.Label(testes_window, text="Resultado:").pack()
    resultado_entry = tk.Entry(testes_window)
    resultado_entry.pack()

    tk.Label(testes_window, text="Equipamentos:").pack()
    equipamentos_entry = tk.Entry(testes_window)
    equipamentos_entry.pack()

    tk.Label(testes_window, text="OM Responsável:").pack()
    om_responsavel_entry = tk.Entry(testes_window)
    om_responsavel_entry.pack()

    tk.Label(testes_window, text="Data Início:").pack()
    data_inicio_entry = DateEntry(testes_window, width=12, background='darkblue', foreground='white', borderwidth=2, date_pattern='dd/mm/yy')
    data_inicio_entry.pack()

    tk.Label(testes_window, text="Data Fim:").pack()
    data_fim_entry = DateEntry(testes_window, width=12, background='darkblue', foreground='white', borderwidth=2, date_pattern='dd/mm/yy')
    data_fim_entry.pack()

    def salvar():
        data_inicio = data_inicio_entry.get()
        data_fim = data_fim_entry.get()

        if not verificar_datas(data_inicio, data_fim):
            messagebox.showerror("Erro", "Data de término não pode ser anterior à data de início ou as datas são inválidas.")
            return

        salvar_teste(
            usuario_id,
            descricao_entry.get("1.0", tk.END).strip(),
            resultado_entry.get(),
            equipamentos_entry.get(),
            om_responsavel_entry.get(),
            autor_entry.get(),
            titulo_entry.get(),
            data_inicio,
            data_fim
        )

        messagebox.showinfo("Sucesso", "Teste salvo!")
        limpar_campos()

    tk.Button(testes_window, text="Salvar Teste", command=salvar).pack(pady=10)
    tk.Button(testes_window, text="Voltar à Tela Inicial", command=lambda: voltar_tela_inicial(usuario_id)).pack(pady=10)

    testes_window.mainloop()

if __name__ == "__main__":
    usuario_id = 1
    tela_testes(usuario_id)
