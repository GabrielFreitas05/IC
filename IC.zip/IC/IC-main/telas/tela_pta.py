from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QCalendarWidget, QTextEdit, QDateEdit, QSizePolicy
)
from PyQt6.QtGui import QFont, QColor, QPalette
from PyQt6.QtCore import QDate
import sqlite3

def tela_pta(usuario_logado):
    tela = TelaPTA(usuario_logado)
    tela.show()

class HoverButton(QPushButton):
    def __init__(self, texto):
        super().__init__(texto)
        self.setStyleSheet("""
            QPushButton {
                background-color: #1B3A5E;
                color: white;
                padding: 10px;
                border-radius: 8px;
                font-size: 12pt;
            }
            QPushButton:hover {
                background-color: #FFB800;
                color: black;
            }
        """)

class HoverTextEdit(QTextEdit):
    def __init__(self):
        super().__init__()
        self.setStyleSheet("""
            background-color: #ffffff;
            border: 2px solid #1B3A5E;
            padding: 10px;
            border-radius: 8px;
            font-size: 12pt;
        """)

    def enterEvent(self, event):
        self.setStyleSheet("""
            background-color: #ffffff;
            border: 2px solid #FFB800;
            padding: 10px;
            border-radius: 8px;
            font-size: 12pt;
        """)

    def leaveEvent(self, event):
        self.setStyleSheet("""
            background-color: #ffffff;
            border: 2px solid #1B3A5E;
            padding: 10px;
            border-radius: 8px;
            font-size: 12pt;
        """)

class HoverDateEdit(QDateEdit):
    def __init__(self):
        super().__init__()
        self.setCalendarPopup(True)
        calendar = QCalendarWidget(self)
        calendar.setGridVisible(True)
        calendar.setStyleSheet("""
            QToolButton {
                color: #1B3A5E;
                font-weight: bold;
            }
            QCalendarWidget QAbstractItemView {
                font-size: 12pt;
                color: black;
            }
        """)
        self.setCalendarWidget(calendar)
        self.setStyleSheet("""
            background-color: #ffffff;
            border: 2px solid #1B3A5E;
            padding: 10px;
            border-radius: 8px;
            font-size: 12pt;
        """)

    def enterEvent(self, event):
        self.setStyleSheet("""
            background-color: #ffffff;
            border: 2px solid #FFB800;
            padding: 10px;
            border-radius: 8px;
            font-size: 12pt;
        """)

    def leaveEvent(self, event):
        self.setStyleSheet("""
            background-color: #ffffff;
            border: 2px solid #1B3A5E;
            padding: 10px;
            border-radius: 8px;
            font-size: 12pt;
        """)

class TelaPTA(QWidget):
    def __init__(self, usuario_logado):
        super().__init__()
        self.usuario_logado = usuario_logado
        self.setWindowTitle("PTA - Planejamento Técnico de Atividades")
        self.setMinimumSize(600, 400)

        layout = QVBoxLayout()

        titulo = QLabel("Planejamento Técnico de Atividades")
        titulo.setFont(QFont("Arial", 20))
        titulo.setStyleSheet("color: #1B3A5E; margin-bottom: 20px;")
        layout.addWidget(titulo)

        usuario_label = QLabel(f"Usuário logado: {self.usuario_logado}")
        usuario_label.setFont(QFont("Arial", 12))
        layout.addWidget(usuario_label)

        data_layout = QHBoxLayout()
        data_label = QLabel("Data:")
        data_label.setFont(QFont("Arial", 12))
        self.data_edit = HoverDateEdit()
        self.data_edit.setDate(QDate.currentDate())
        data_layout.addWidget(data_label)
        data_layout.addWidget(self.data_edit)
        layout.addLayout(data_layout)

        descricao_label = QLabel("Descrição da Atividade:")
        descricao_label.setFont(QFont("Arial", 12))
        self.descricao_edit = HoverTextEdit()
        self.descricao_edit.setMinimumHeight(100)

        layout.addWidget(descricao_label)
        layout.addWidget(self.descricao_edit)

        salvar_button = HoverButton("Salvar Atividade")
        salvar_button.clicked.connect(self.salvar_atividade)
        layout.addWidget(salvar_button)

        self.setLayout(layout)
        self.setStyleSheet("background-color: #F5F5F5; padding: 20px;")

    def salvar_atividade(self):
        data = self.data_edit.date().toString("yyyy-MM-dd")
        descricao = self.descricao_edit.toPlainText()
        usuario = self.usuario_logado

        conn = sqlite3.connect("db/usuarios.db")
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS pta (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario TEXT,
                data TEXT,
                descricao TEXT
            )
        """)
        cursor.execute("INSERT INTO pta (usuario, data, descricao) VALUES (?, ?, ?)",
                       (usuario, data, descricao))
        conn.commit()
        conn.close()

        self.descricao_edit.clear()
