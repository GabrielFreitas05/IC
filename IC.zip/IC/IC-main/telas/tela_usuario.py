from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QSpacerItem,
    QSizePolicy, QFrame
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QPixmap, QColor, QIcon
from telas.tela_testes import tela_testes
from telas.tela_pesquisa import tela_pesquisa
from telas.tela_historico import tela_historico
from telas.tela_pta import tela_pta
from db.db import buscar_nome_usuario, buscar_id_usuario
import os

class HoverButton(QPushButton):
    def __init__(self, text, icon_path=None, function=None, enabled=True):
        super().__init__(text)
        self.function = function
        self.enabled = enabled
        if icon_path and os.path.exists(icon_path):
            self.setIcon(QIcon(icon_path))
            self.setIconSize(QPixmap(icon_path).rect().size())
        self.update_style()

    def update_style(self):
        if self.enabled:
            self.setStyleSheet("""
                QPushButton {
                    background-color: #FFCD00;
                    color: #1B3A5E;
                    font-size: 16px;
                    font-weight: bold;
                    border-radius: 15px;
                    padding: 15px;
                    border: none;
                }
                QPushButton:hover {
                    background-color: #e5b800;
                }
            """)
        else:
            self.setStyleSheet("""
                QPushButton {
                    background-color: #cccccc;
                    color: #666666;
                    font-size: 16px;
                    font-weight: bold;
                    border-radius: 15px;
                    padding: 15px;
                }
            """)
            self.setEnabled(False)

    def mousePressEvent(self, event):
        if self.enabled and self.function:
            self.function()

def tela_usuario(usuario_id):
    usuario_window = QWidget()
    usuario_window.setWindowTitle("Tela Inicial")
    usuario_window.setFixedSize(700, 550)

    bg_color = "#1B3A5E"
    fg_color = "#FFCD00"

    usuario_window.setStyleSheet(f"background-color: {bg_color};")

    layout = QVBoxLayout()
    layout.setSpacing(20)

    # Buscar o nome do usuário a partir do ID
    nome_usuario = buscar_nome_usuario(usuario_id)

    # Gerar as iniciais do nome do usuário
    iniciais = gerar_iniciais(nome_usuario)

    # Gerar o ID no formato "JDS-003"
    usuario_id_formatado = gerar_id_formatado(iniciais, usuario_id)

    # Título
    title = QLabel(f"Bem-vindo, {nome_usuario}")
    title.setAlignment(Qt.AlignmentFlag.AlignCenter)
    title.setStyleSheet("font-size: 26px; color: white; font-weight: bold;")
    layout.addWidget(title)

    # Subtítulo
    subtitle = QLabel("Sistema de Gestão de Conhecimento e Inovação")
    subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
    subtitle.setStyleSheet(f"font-size: 16px; color: {fg_color};")
    layout.addWidget(subtitle)

    # Ícone central (caso queira usar logotipo)
    logo_path = "assets/logo.png"  # Caminho opcional
    if os.path.exists(logo_path):
        logo = QLabel()
        pixmap = QPixmap(logo_path).scaled(100, 100, Qt.AspectRatioMode.KeepAspectRatio)
        logo.setPixmap(pixmap)
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(logo)

    # Separador
    line = QFrame()
    line.setFrameShape(QFrame.Shape.HLine)
    line.setFrameShadow(QFrame.Shadow.Sunken)
    line.setStyleSheet("color: white;")
    layout.addWidget(line)

    # Botões organizados em linha
    button_layout = QHBoxLayout()
    button_layout.setSpacing(20)

    def create_button(text, icon=None, function=None, enabled=True):
        return HoverButton(text, icon_path=icon, function=lambda: [usuario_window.hide(), function(usuario_id)] if function else None, enabled=enabled)

    button_layout.addWidget(create_button("POP", "assets/icon_pop.png", tela_testes, True))
    button_layout.addWidget(create_button("PTA", "assets/icon_pta.png", tela_pta, True))
    button_layout.addWidget(create_button("Pesquisa", "assets/icon_search.png", tela_pesquisa, True))
    button_layout.addWidget(create_button("Histórico", "assets/icon_history.png", tela_historico, True))

    layout.addLayout(button_layout)

    # Exibindo o ID do usuário formatado no canto inferior direito
    id_label = QLabel(f"ID: {usuario_id_formatado}")
    id_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignBottom)
    id_label.setStyleSheet("font-size: 12px; color: white; margin-right: 10px; margin-bottom: 10px;")
    layout.addWidget(id_label)

    usuario_window.setLayout(layout)
    usuario_window.show()

def gerar_iniciais(nome_usuario):
    """Função para gerar as iniciais do nome do usuário"""
    partes = nome_usuario.split()  # Dividir o nome por espaços
    iniciais = ''.join([parte[0].upper() for parte in partes if parte])  # Pega a primeira letra de cada parte
    return iniciais

def gerar_id_formatado(iniciais, usuario_id):
    """Função para gerar o ID completo no formato 'JDS-003'"""
    numero = f"{usuario_id:03d}"  # Aqui você pode adaptar de acordo com o seu banco de dados
    return f"{iniciais}-{numero}"
