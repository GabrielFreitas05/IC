from docx import Document
import os

def preencher_pop(dados, caminho_modelo):
    doc = Document(caminho_modelo)

    for paragrafo in doc.paragraphs:
        for chave, valor in dados.items():
            texto_original = ''.join(run.text for run in paragrafo.runs)
            if f"{{{{{chave}}}}}" in texto_original:
                novo_texto = texto_original.replace(f"{{{{{chave}}}}}", valor)
                for i in range(len(paragrafo.runs)):
                    paragrafo.runs[i].text = ''
                paragrafo.runs[0].text = novo_texto

    for tabela in doc.tables:
        for linha in tabela.rows:
            for celula in linha.cells:
                for paragrafo in celula.paragraphs:
                    for chave, valor in dados.items():
                        texto_original = ''.join(run.text for run in paragrafo.runs)
                        if f"{{{{{chave}}}}}" in texto_original:
                            novo_texto = texto_original.replace(f"{{{{{chave}}}}}", valor)
                            for i in range(len(paragrafo.runs)):
                                paragrafo.runs[i].text = ''
                            paragrafo.runs[0].text = novo_texto

    nome_arquivo = f"{dados['codigo_documento']}_POP.docx"
    caminho_saida = os.path.join("assets", nome_arquivo)
    doc.save(caminho_saida)
    return caminho_saida
