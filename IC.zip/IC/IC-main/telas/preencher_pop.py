from docx import Document
from docx.shared import Inches
import os

def preencher_pop(dados, caminho_modelo):
    doc = Document(caminho_modelo)

    for paragrafo in doc.paragraphs:
        texto_original = ''.join(run.text for run in paragrafo.runs)
        for chave, valor in dados.items():
            if chave == "imagem" or chave == "anexos":
                continue
            placeholder = f"{{{{{chave}}}}}"
            if placeholder in texto_original:
                novo_texto = texto_original.replace(placeholder, valor)
                for run in paragrafo.runs:
                    run.text = ''
                paragrafo.runs[0].text = novo_texto
                texto_original = novo_texto

    for tabela in doc.tables:
        for linha in tabela.rows:
            for celula in linha.cells:
                for paragrafo in celula.paragraphs:
                    texto_original = ''.join(run.text for run in paragrafo.runs)
                    for chave, valor in dados.items():
                        if chave == "imagem" or chave == "anexos":
                            continue
                        placeholder = f"{{{{{chave}}}}}"
                        if placeholder in texto_original:
                            novo_texto = texto_original.replace(placeholder, valor)
                            for run in paragrafo.runs:
                                run.text = ''
                            paragrafo.runs[0].text = novo_texto
                            texto_original = novo_texto

    if "imagem" in dados and dados["imagem"]:
        imagens = dados["imagem"]
        if isinstance(imagens, str):
            imagens = [imagens]
        for paragrafo in doc.paragraphs:
            if '{{anexos}}' in paragrafo.text:
                texto_original = paragrafo.text
                paragrafo.text = texto_original.replace('{{anexos}}', '')
                for imagem in imagens:
                    run = paragrafo.add_run()
                    try:
                        run.add_picture(imagem, width=Inches(4))
                    except Exception as e:
                        paragrafo.add_run(f"[Erro ao inserir imagem: {str(e)}]")
                break

    nome_arquivo = f"{dados['titulo_procedimento']}_POP.docx"
    caminho_temporario = os.path.join("assets", nome_arquivo)
    doc.save(caminho_temporario)
    return caminho_temporario
