from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QFormLayout, QLabel, QLineEdit,
    QTextEdit, QPushButton, QComboBox, QStackedLayout, QHBoxLayout,
    QMessageBox, QDateEdit
)
from PyQt6.QtGui import QFont
from PyQt6.QtCore import Qt, QDate
import sqlite3
import sys

AZUL_IAE = "#003366"
AMARELO_IAE = "#FFCC00"

class HoverButton(QPushButton):
    def __init__(self, text, function=None):
        super().__init__(text)
        self.setFont(QFont("Arial", 11, QFont.Weight.Bold))
        self.setStyleSheet(f'''
            QPushButton {{
                background-color: {AZUL_IAE};
                color: white;
                padding: 10px;
                border-radius: 8px;
            }}
            QPushButton:hover {{
                background-color: {AMARELO_IAE};
                color: {AZUL_IAE};
            }}
        ''')
        if function:
            self.clicked.connect(function)

class ProcessoScreen(QWidget):
    def __init__(self, usuario_id=None):
        super().__init__()
        self.usuario_id = usuario_id
        self.setWindowTitle("Cadastro de Processo")
        self.setMinimumSize(700, 500)

        self.layout = QVBoxLayout(self)
        self.step_indicator = QLabel()
        self.step_indicator.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.step_indicator.setFont(QFont("Arial", 14, QFont.Weight.Bold))
        self.step_indicator.setStyleSheet(f"color: {AZUL_IAE};")

        self.etapa_atual = 0
        self.layout.addWidget(self.step_indicator)

        self.criar_barra_progresso()

        self.stacked_layout = QStackedLayout()
        self.layout.addLayout(self.stacked_layout)

        self.init_etapa1()
        self.init_etapa2()
        self.init_etapa3()

        self.atualizar_etapa()
        self.atualizar_barra()

    def criar_barra_progresso(self):
        self.barra = QHBoxLayout()
        self.etapas = []
        nomes = ["Identificação", "Estrutura", "Execução"]
        for i, nome in enumerate(nomes):
            etapa = QLabel()
            etapa.setAlignment(Qt.AlignmentFlag.AlignCenter)
            etapa.setFont(QFont("Arial", 10, QFont.Weight.Bold))
            etapa.setText(f"🟢 {nome}" if i == self.etapa_atual else f"⚪ {nome}")
            etapa.setStyleSheet("margin: 10px;")
            self.etapas.append(etapa)
            self.barra.addWidget(etapa)
        self.layout.addLayout(self.barra)

    def atualizar_barra(self):
        nomes = ["Identificação", "Estrutura", "Execução"]
        for i, etapa in enumerate(self.etapas):
            etapa.setText(f"🟢 {nomes[i]}" if i == self.etapa_atual else f"⚪ {nomes[i]}")

    def init_etapa1(self):
        self.etapa1 = QWidget()
        layout = QFormLayout()
        self.input_titulo = QLineEdit()
        self.input_responsavel = QLineEdit()
        self.input_codigo = QLineEdit()
        layout.addRow("Título do Processo:", self.input_titulo)
        layout.addRow("Responsável:", self.input_responsavel)
        layout.addRow("Código do Processo:", self.input_codigo)
        btn_next = HoverButton("Próximo", self.ir_para_etapa2)
        layout.addRow(btn_next)
        self.etapa1.setLayout(layout)
        self.stacked_layout.addWidget(self.etapa1)

    def init_etapa2(self):
        self.etapa2 = QWidget()
        layout = QFormLayout()
        self.input_objetivo = QTextEdit()
        self.input_descricao = QTextEdit()
        self.input_materiais = QTextEdit()
        layout.addRow("Objetivo:", self.input_objetivo)
        layout.addRow("Descrição:", self.input_descricao)
        layout.addRow("Materiais/Equipamentos:", self.input_materiais)
        btn_next = HoverButton("Próximo", self.ir_para_etapa3)
        btn_back = HoverButton("Voltar", self.ir_para_etapa1)
        btns = QHBoxLayout()
        btns.addWidget(btn_back)
        btns.addWidget(btn_next)
        layout.addRow(btns)
        self.etapa2.setLayout(layout)
        self.stacked_layout.addWidget(self.etapa2)

    def init_etapa3(self):
        self.etapa3 = QWidget()
        layout = QFormLayout()
        self.input_etapas = QTextEdit()
        self.input_status = QComboBox()
        self.input_status.addItems(["Em andamento", "Concluído", "Aguardando"])
        self.input_observacoes = QTextEdit()
        self.input_data_inicio = QDateEdit()
        self.input_data_inicio.setCalendarPopup(True)
        self.input_data_inicio.setDate(QDate.currentDate())
        self.input_data_fim = QDateEdit()
        self.input_data_fim.setCalendarPopup(True)
        self.input_data_fim.setDate(QDate.currentDate())
        layout.addRow("Etapas:", self.input_etapas)
        layout.addRow("Status:", self.input_status)
        layout.addRow("Observações:", self.input_observacoes)
        layout.addRow("Data de Início:", self.input_data_inicio)
        layout.addRow("Data de Término:", self.input_data_fim)
        btn_save = HoverButton("Salvar Processo", self.salvar_processo)
        btn_back = HoverButton("Voltar", self.ir_para_etapa2)
        btns = QHBoxLayout()
        btns.addWidget(btn_back)
        btns.addWidget(btn_save)
        layout.addRow(btns)
        self.etapa3.setLayout(layout)
        self.stacked_layout.addWidget(self.etapa3)

    def atualizar_etapa(self):
        textos = ["IDENTIFICAÇÃO", "ESTRUTURA", "EXECUÇÃO"]
        self.step_indicator.setText(f"Etapa {self.etapa_atual + 1}: {textos[self.etapa_atual]}")
        self.stacked_layout.setCurrentIndex(self.etapa_atual)
        self.atualizar_barra()

    def ir_para_etapa1(self):
        self.etapa_atual = 0
        self.atualizar_etapa()

    def ir_para_etapa2(self):
        if not self.input_titulo.text() or not self.input_responsavel.text():
            QMessageBox.warning(self, "Campos obrigatórios", "Preencha título e responsável.")
            return
        self.etapa_atual = 1
        self.atualizar_etapa()

    def ir_para_etapa3(self):
        if not self.input_objetivo.toPlainText() or not self.input_descricao.toPlainText():
            QMessageBox.warning(self, "Campos obrigatórios", "Preencha objetivo e descrição.")
            return
        self.etapa_atual = 2
        self.atualizar_etapa()

    def salvar_processo(self):
        try:
            conn = sqlite3.connect("db/usuarios.db")
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS processos (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    usuario_id INTEGER,
                    titulo TEXT,
                    responsavel TEXT,
                    codigo TEXT,
                    objetivo TEXT,
                    descricao TEXT,
                    materiais TEXT,
                    etapas TEXT,
                    status TEXT,
                    observacoes TEXT,
                    data_inicio TEXT,
                    data_fim TEXT
                )
            """)
            cursor.execute("""
                INSERT INTO processos (
                    usuario_id, titulo, responsavel, codigo, objetivo, descricao,
                    materiais, etapas, status, observacoes, data_inicio, data_fim
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                self.usuario_id,
                self.input_titulo.text(),
                self.input_responsavel.text(),
                self.input_codigo.text(),
                self.input_objetivo.toPlainText(),
                self.input_descricao.toPlainText(),
                self.input_materiais.toPlainText(),
                self.input_etapas.toPlainText(),
                self.input_status.currentText(),
                self.input_observacoes.toPlainText(),
                self.input_data_inicio.date().toString("yyyy-MM-dd"),
                self.input_data_fim.date().toString("yyyy-MM-dd")
            ))
            conn.commit()
            conn.close()

            escolha = QMessageBox.question(
                self,
                "Processo salvo",
                "Processo salvo com sucesso!\nDeseja retornar para a tela inicial?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No | QMessageBox.StandardButton.Cancel,
                QMessageBox.StandardButton.Yes
            )

            if escolha == QMessageBox.StandardButton.Yes:
                from telas.tela_usuario import tela_usuario
                self.close()
                tela_usuario(self.usuario_id)
            elif escolha == QMessageBox.StandardButton.No:
                self.close()
                nova = ProcessoScreen(self.usuario_id)
                nova.show()
            else:
                pass

        except Exception as e:
            QMessageBox.critical(self, "Erro", f"Erro ao salvar: {str(e)}")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ProcessoScreen(usuario_id=1)
    window.show()
    sys.exit(app.exec())