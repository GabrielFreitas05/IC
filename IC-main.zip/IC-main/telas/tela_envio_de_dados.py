import tkinter as tk

def tela_envio_dados():
    pass
