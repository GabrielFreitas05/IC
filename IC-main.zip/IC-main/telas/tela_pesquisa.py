from telas.tela_envio_de_dados import TelaPesquisa
