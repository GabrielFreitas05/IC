
from PyQt6.QtWidgets import QWidget, QLabel, QVBoxLayout
from PyQt6.QtCore import Qt

class TelaPTA(QWidget):
    def __init__(self, usuario_id):
        super().__init__()
        self.usuario_id = usuario_id
        self.setWindowTitle("Tela PTA")
        self.setMinimumSize(600, 400)

        layout = QVBoxLayout()
        label = QLabel(f"Tela PTA - Usuário ID: {usuario_id}")
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        label.setStyleSheet("font-size: 18px; color: #003366;")
        layout.addWidget(label)

        self.setLayout(layout)
