
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel
from PyQt6.QtGui import QFont
from PyQt6.QtCore import Qt
from telas.tela_processos import ProcessoScreen
# from telas.listar_processos import ListarProcessosScreen  # a ser criada
from components.icon_button import IconButton

class MenuProcessos(QWidget):
    def __init__(self, usuario_id):
        super().__init__()
        self.usuario_id = usuario_id
        self.setWindowTitle("Menu de Processos")
        self.setMinimumSize(400, 300)

        layout = QVBoxLayout()
        label = QLabel("Gerenciar Processos")
        label.setFont(QFont("Arial", 14, QFont.Weight.Bold))
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(label)

        layout.addWidget(IconButton("Criar Novo Processo", "assets/icon_add.png", lambda: self.abrir(ProcessoScreen)))
        layout.addWidget(IconButton("Listar / Editar / Excluir", "assets/icon_list.png", lambda: self.abrir_listagem()))

        self.setLayout(layout)

    def abrir(self, tela):
        self.hide()
        janela = tela(self.usuario_id)
        janela.show()

    def abrir_listagem(self):
        print("Aqui abrirá a tela de listagem de processos futuramente.")
