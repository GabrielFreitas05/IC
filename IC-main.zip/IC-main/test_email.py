from utils.emailer import send_email

ok, err = send_email("gmaeagendamentos@gmail.com", "Teste SMTP", "Funcionou?")
print(ok, err)
